import React, { useState, useEffect } from 'react';
import { Sun, Calendar, Moon, SunDim } from 'lucide-react';
import { GregorianCard } from './components/cards/GregorianCard';
import { CurrentTimeCard } from './components/cards/CurrentTimeCard';
import { NextPrayerCard } from './components/cards/NextPrayerCard';
import { CircularTimeCard } from './components/cards/CircularTimeCard';
import { InspirationCard } from './components/cards/InspirationCard';
import { FastingTimeCard } from './components/cards/FastingTimeCard';
import { PrayerTimeline } from './components/PrayerTimeline';
import { usePrayerTimes } from './hooks/usePrayerTimes';
import { useNextPrayer } from './hooks/useNextPrayer';
import { getAdjustedTime } from './utils/timeUtils';

function App() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [editMode, setEditMode] = useState(false);
  
  const { times, timeOffsets, handleOffsetChange } = usePrayerTimes();
  const { nextPrayer, timeToNextPrayer } = useNextPrayer(times, timeOffsets);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const prayerTimesDisplay = {
    Fajr: { key: 'fajr', time: times.fajr, arabic: 'الفجر', icon: Sun },
    Sunrise: { key: 'sunrise', time: times.sunrise, arabic: 'الشروق', icon: Sun },
    Zuhr: { key: 'dhuhr', time: times.dhuhr, arabic: 'الظهر', icon: Sun },
    Asr: { key: 'asr', time: times.asr, arabic: 'العصر', icon: Sun },
    Maghrib: { key: 'maghrib', time: times.maghrib, arabic: 'المغرب', icon: Sun },
    Isha: { key: 'isha', time: times.isha, arabic: 'العشاء', icon: Sun },
  };

  return (
    <div className="min-h-screen bg-islamic-primary bg-pattern p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header Section */}
        <div className="grid grid-cols-3 gap-8">
          {/* Combined Gregorian & Hijri Card */}
          <div className="gradient-border col-span-2">
            <div className="glass-effect card-glow rounded-2xl p-6 h-full transform hover:scale-105 transition-all duration-500">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Calendar className="w-10 h-10 text-islamic-secondary animate-pulse-slow" />
                  <div>
                    <p className="text-xl font-bold text-islamic-light font-arabic">Gregorian</p>
                    <p className="text-base text-islamic-dark">
                      {currentTime.toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <Moon className="w-10 h-10 text-islamic-secondary animate-pulse-slow" />
                  <div>
                    <p className="text-xl font-bold text-islamic-light font-arabic">Hijri</p>
                    <p className="text-base text-islamic-dark">15 Ramadan 1445</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Current Time Card */}
          <div className="gradient-border">
            <div className="glass-effect prayer-card-glow rounded-2xl p-4 h-full bg-gradient-radial from-islamic-tertiary/40 to-transparent flex items-center justify-center">
              <p className="text-4xl font-black text-islamic-secondary font-arabic">
                {currentTime.toLocaleTimeString('en-US', { hour12: true })}
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex gap-8">
          {/* Left Section */}
          <div className="w-2/3 space-y-8">
            {/* Top Row */}
            <div className="flex items-center justify-between gap-8">
              <CircularTimeCard
                Icon={Sun}
                title="Sunrise"
                time={getAdjustedTime('sunrise', times.sunrise, timeOffsets)}
              />
              
              <NextPrayerCard
                nextPrayer={nextPrayer}
                arabicNameForNextPrayer={prayerTimesDisplay[nextPrayer]?.arabic || ''}
                timeToNextPrayer={timeToNextPrayer}
              />
              
              <CircularTimeCard
                Icon={SunDim}
                title="Sunset"
                time={getAdjustedTime('maghrib', times.maghrib, timeOffsets)}
              />
            </div>

            {/* Bottom Row */}
            <div className="grid grid-cols-2 gap-8">
              <InspirationCard
                title="Hadith of the Day"
                arabicText="عن أبي هريرة رضي الله عنه"
                translation="The best charity is that which is given when one is in need and struggling."
              />
              
              <InspirationCard
                title="Verse of the Day"
                arabicText="وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ"
                translation='"And when My servants ask you concerning Me, indeed I am near." (2:186)'
              />
              
              <FastingTimeCard
                title="Sehri Time"
                arabicTitle="وقت السحور"
                time={getAdjustedTime('fajr', times.fajr, timeOffsets)}
              />
              
              <FastingTimeCard
                title="Iftiyaar Time"
                arabicTitle="وقت الإفطار"
                time={getAdjustedTime('maghrib', times.maghrib, timeOffsets)}
              />
            </div>
          </div>

          {/* Right Section: Prayer Timeline (Full Height) */}
          <div className="w-1/3">
            <div className="sticky top-6">
              <PrayerTimeline
                prayerTimes={Object.entries(prayerTimesDisplay).map(([name, data]) => ({
                  name,
                  ...data,
                }))}
                editMode={editMode}
                onEditModeToggle={() => setEditMode(!editMode)}
                onOffsetChange={handleOffsetChange}
                getAdjustedTime={(key, time) => getAdjustedTime(key, time, timeOffsets)}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;