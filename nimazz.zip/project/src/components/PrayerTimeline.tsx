import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface PrayerTimeEntry {
  name: string;
  key: string;
  time: string;
  arabic: string;
  icon: LucideIcon;
}

interface PrayerTimelineProps {
  prayerTimes: PrayerTimeEntry[];
  editMode: boolean;
  onEditModeToggle: () => void;
  onOffsetChange: (key: string, delta: number) => void;
  getAdjustedTime: (key: string, time: string) => string;
}

export function PrayerTimeline({
  prayerTimes,
  editMode,
  onEditModeToggle,
  onOffsetChange,
  getAdjustedTime,
}: PrayerTimelineProps) {
  return (
    <div className="relative group">
      <button
        onClick={onEditModeToggle}
        className="absolute right-4 top-4 bg-red-500 text-white px-4 py-2 rounded-md opacity-0 
                   group-hover:opacity-100 transition-opacity duration-300 z-10"
      >
        {editMode ? 'Close Edit' : 'Edit Times'}
      </button>

      <div className="gradient-border">
        <div className="glass-effect card-glow rounded-2xl p-6">
          <div className="w-full max-w-sm mx-auto mb-6">
            <h2 className="text-3xl text-center font-bold font-arabic text-green-500">
              Prayer Times
            </h2>
          </div>

          <div className="space-y-4">
            {prayerTimes.map(({ name, key, time, arabic, icon: Icon }) => (
              <div
                key={name}
                className="gradient-border overflow-hidden prayer-card-glow"
              >
                <div className="p-4 rounded-xl transition-all duration-500 bg-gradient-to-r from-islamic-tertiary/40 to-transparent">
                  <div className="grid grid-cols-3 items-center">
                    {/* Left: English name and icon */}
                    <div className="flex items-center space-x-3">
                      <Icon className="w-6 h-6 text-green-500" />
                      <span className="font-medium text-lg font-arabic text-green-400">
                        {name}
                      </span>
                    </div>

                    {/* Center: Time */}
                    <div className="flex justify-center">
                      <span className="font-bold text-xl font-arabic text-islamic-secondary">
                        {getAdjustedTime(key, time)}
                      </span>
                    </div>

                    {/* Right: Arabic name and edit buttons */}
                    <div className="flex items-center justify-end">
                      <span className="text-base font-arabic text-green-500 mr-2">
                        {arabic}
                      </span>

                      {editMode && (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => onOffsetChange(key, +1)}
                            className="bg-green-500 text-white px-2 py-1 rounded hover:bg-green-600 text-sm"
                          >
                            +1
                          </button>
                          <button
                            onClick={() => onOffsetChange(key, -1)}
                            className="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 text-sm"
                          >
                            -1
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}