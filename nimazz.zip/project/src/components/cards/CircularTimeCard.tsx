import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface CircularTimeCardProps {
  Icon: LucideIcon;
  title: string;
  time: string;
}

export function CircularTimeCard({ Icon, title, time }: CircularTimeCardProps) {
  return (
    <div className="circular-card transform hover:scale-105 transition-all duration-500">
      <div className="circular-card-inner">
        <Icon className="w-12 h-12 text-islamic-secondary mb-2" />
        <p className="text-lg text-islamic-dark font-arabic">{title}</p>
        <p className="text-2xl font-bold text-islamic-secondary font-arabic">
          {time}
        </p>
      </div>
    </div>
  );
}