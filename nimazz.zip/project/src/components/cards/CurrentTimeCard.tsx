import React from 'react';

interface CurrentTimeCardProps {
  currentTime: Date;
}

export function CurrentTimeCard({ currentTime }: CurrentTimeCardProps) {
  return (
    <div className="gradient-border">
      <div className="glass-effect prayer-card-glow rounded-2xl p-8 h-full bg-gradient-radial from-islamic-tertiary/40 to-transparent flex items-center justify-center">
        <p className="text-6xl font-black text-islamic-secondary font-arabic">
          {currentTime.toLocaleTimeString('en-US', { hour12: true })}
        </p>
      </div>
    </div>
  );
}