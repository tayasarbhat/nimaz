import React from 'react';

interface FastingTimeCardProps {
  title: string;
  arabicTitle: string;
  time: string;
}

export function FastingTimeCard({
  title,
  arabicTitle,
  time,
}: FastingTimeCardProps) {
  return (
    <div className="gradient-border">
      <div className="glass-effect prayer-card-glow rounded-2xl p-8 h-full bg-gradient-radial from-islamic-tertiary/40 to-transparent">
        <h3 className="text-2xl font-bold text-center text-islamic-light font-arabic mb-6">
          {title}
        </h3>
        <div className="flex flex-col items-center justify-center space-y-4">
          <p className="text-3xl font-black font-arabic mb-2 text-green-500">
            {arabicTitle}
          </p>
          <p className="text-6xl font-black text-islamic-secondary font-arabic">
            {time || 'Loading...'}
          </p>
        </div>
      </div>
    </div>
  );
}