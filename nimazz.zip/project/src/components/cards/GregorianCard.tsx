import React from 'react';
import { Calendar } from 'lucide-react';

interface GregorianCardProps {
  currentTime: Date;
}

export function GregorianCard({ currentTime }: GregorianCardProps) {
  return (
    <div className="gradient-border">
      <div className="glass-effect card-glow rounded-2xl p-8 h-full transform hover:scale-105 transition-all duration-500">
        <div className="flex flex-col items-center justify-center space-y-3">
          <Calendar className="w-12 h-12 text-islamic-secondary animate-pulse-slow" />
          <p className="text-2xl font-bold text-islamic-light font-arabic">
            Gregorian
          </p>
          <p  className="text-2xl font-bold text-islamic-light font-arabic">
            {currentTime.toLocaleDateString('en-US', {
              weekday: 'long',
            })}
          </p>
          <p  style={{ color: 'green' }} className="text-lg text-islamic-dark">
            {currentTime.toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </p>
        </div>
      </div>
    </div>
  );
}