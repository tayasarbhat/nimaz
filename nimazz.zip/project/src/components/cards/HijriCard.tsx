import React from 'react';
import { Moon } from 'lucide-react';

export function HijriCard() {
  return (
    <div className="gradient-border">
      <div className="glass-effect card-glow rounded-2xl p-8 h-full transform hover:scale-105 transition-all duration-500">
        <div className="flex flex-col items-center justify-center space-y-3">
          <Moon className="w-12 h-12 text-islamic-secondary animate-pulse-slow" />
          <p className="text-2xl font-bold text-islamic-light font-arabic">
            Hijri
          </p>
          <p className="text-2xl font-bold text-islamic-light font-arabic">
            15 Ramadan
          </p>
          <p className="text-lg text-islamic-dark">1445 Hijri</p>
        </div>
      </div>
    </div>
  );
}