import React from 'react';

interface InspirationCardProps {
  title: string;
  arabicText: string;
  translation: string;
}

export function InspirationCard({
  title,
  arabicText,
  translation,
}: InspirationCardProps) {
  return (
    <div className="gradient-border">
      <div className="glass-effect card-glow rounded-2xl p-8 h-full">
        <h3 className="text-2xl font-bold text-islamic-light font-arabic mb-4">
          {title}
        </h3>
        <p className="text-xl text-islamic-secondary mb-4 font-arabic text-green-500">
          {arabicText}
        </p>
        <p className="text-lg text-islamic-dark font-arabic">{translation}</p>
      </div>
    </div>
  );
}