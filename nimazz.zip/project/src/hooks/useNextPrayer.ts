import { useState, useEffect } from 'react';
import { parseTimeWithOffset, formatTime } from '../utils/timeUtils';

export function useNextPrayer(times: any, timeOffsets: any) {
  const [nextPrayer, setNextPrayer] = useState('');
  const [timeToNextPrayer, setTimeToNextPrayer] = useState('');

  useEffect(() => {
    const interval = setInterval(calculateNextPrayer, 60_000);
    calculateNextPrayer();
    return () => clearInterval(interval);
  }, [times, timeOffsets]);

  function calculateNextPrayer() {
    if (!times.fajr || times.fajr === 'Loading...') return;

    const now = new Date();
    const prayers = [
      { name: 'Fajr', date: parseTimeWithOffset(times.fajr, timeOffsets.fajr) },
      { name: 'Zuhr', date: parseTimeWithOffset(times.dhuhr, timeOffsets.dhuhr) },
      { name: 'Asr', date: parseTimeWithOffset(times.asr, timeOffsets.asr) },
      {
        name: 'Maghrib',
        date: parseTimeWithOffset(times.maghrib, timeOffsets.maghrib),
      },
      { name: 'Isha', date: parseTimeWithOffset(times.isha, timeOffsets.isha) },
    ];

    let upcoming = prayers.find((prayer) => prayer.date > now) || prayers[0];

    setNextPrayer(upcoming.name);
    setTimeToNextPrayer(formatTime(upcoming.date));
  }

  return { nextPrayer, timeToNextPrayer };
}