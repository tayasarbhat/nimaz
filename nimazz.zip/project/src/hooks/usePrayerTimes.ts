import { useState, useEffect } from 'react';
import prayerTimes from '../prayerTimes';

export function usePrayerTimes() {
  const [times, setTimes] = useState({
    fajr: '',
    sunrise: '',
    dhuhr: '',
    asr: '',
    maghrib: '',
    isha: '',
  });

  const [timeOffsets, setTimeOffsets] = useState({
    fajr: 0,
    sunrise: 0,
    dhuhr: 0,
    asr: 0,
    maghrib: 0,
    isha: 0,
  });

  useEffect(() => {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const dateKey = `${month}-${day}`;

    const todayTimes = prayerTimes[dateKey];
    if (todayTimes) {
      setTimes({
        fajr: todayTimes.fajr,
        sunrise: todayTimes.sunrise,
        dhuhr: todayTimes.dhuhr,
        asr: todayTimes.asr,
        maghrib: todayTimes.maghrib,
        isha: todayTimes.isha,
      });
    }
  }, []);

  const handleOffsetChange = (prayerName: string, delta: number) => {
    setTimeOffsets((prev) => ({
      ...prev,
      [prayerName]: prev[prayerName] + delta,
    }));
  };

  return {
    times,
    timeOffsets,
    handleOffsetChange,
  };
}