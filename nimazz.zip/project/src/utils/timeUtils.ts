export function parseTimeWithOffset(timeString: string, offsetMinutes: number): Date {
  if (!timeString || timeString === 'Loading...') return null;
  
  const [hourStr, minuteStr] = timeString.split(':');
  const hour = parseInt(hourStr, 10);
  const minute = parseInt(minuteStr, 10);
  
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0];
  const dateObj = new Date(`${dateStr}T00:00:00`);
  
  dateObj.setHours(hour, minute, 0, 0);
  dateObj.setMinutes(dateObj.getMinutes() + offsetMinutes);
  
  return dateObj;
}

export function formatTime(dateObj: Date): string {
  if (!dateObj) return '...';
  return dateObj.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
}

export function getAdjustedTime(
  prayerName: string,
  rawTime: string,
  timeOffsets: Record<string, number>
): string {
  return formatTime(parseTimeWithOffset(rawTime, timeOffsets[prayerName]));
}